package com.example.deltatask3;

public class DepDesc {

    String id;
    String description;

    DepDesc()
    {
        id="No id found.";
        description="No description found.";
    }

    public String getID()
    {
        return id;
    }

    public String getDescription()
    {
        return description;
    }
}
