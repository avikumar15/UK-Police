<<<<<<< HEAD
<<<<<<< HEAD
<<<<<<< HEAD
<<<<<<< HEAD
# DeltaTask3_Normal
To make an app that uses an API to fetch data about the police forces in UK and also fetch crime data.
=======
# UKP_T3
>>>>>>> af87d9a8a8c8f281b1634bf45a4fd66550329951
=======
# UKP_T3
>>>>>>> af87d9a8a8c8f281b1634bf45a4fd66550329951
=======
# UKP_T3
UK Police App
>>>>>>> 3be8c70cdc101a97cff94ae347d8472eb536466d
=======
# UKP_T3
UK Police App
>>>>>>> 3be8c70cdc101a97cff94ae347d8472eb536466d
